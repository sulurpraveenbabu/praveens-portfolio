
var typed = new Typed('#element', {
  strings: ['Web Developer','Graphic Designer','Web Designer','Video Editor','Web Developer'],
  typeSpeed: 60,
});
